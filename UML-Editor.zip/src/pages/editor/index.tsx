import '@xyflow/react/dist/style.css';
import './react-flow.scss';

import { toPng } from 'html-to-image';
import React, { useCallback, useState } from 'react';

import {
    AggregationEdge, AssociationEdge, CompositionEdge, InheritanceEdge
} from '@components/edges';
import { EditorToolbar } from '@components/editor-toolbar';
import { UMLClassNode } from '@components/uml-class-node';
import { UMLClassEdgeDTO, UMLEdgeType } from '@ts/uml-class-edge';
import { UMLClassNodeData, UMLClassNodeDTO } from '@ts/uml-class-node';
import { UMLSheetMetaDTO } from '@ts/uml-sheet';
import {
    addEdge, applyEdgeChanges, applyNodeChanges, Background, BackgroundVariant, Connection,
    ConnectionMode, Edge, EdgeChange, getNodesBounds, getViewportForBounds, NodeChange, ReactFlow,
    useReactFlow
} from '@xyflow/react';

const nodeTypes = {
    UMLClass: UMLClassNode,
};

const edgeTypes = {
    association: AssociationEdge,
    inheritance: InheritanceEdge,
    aggregation: AggregationEdge,
    composition: CompositionEdge,
};

export const EditorPage: React.FC = () => {
    const { zoomIn, zoomOut, fitView } = useReactFlow();

    const [nodes, setNodes] = useState<UMLClassNodeDTO[]>([]);
    const [edges, setEdges] = useState<UMLClassEdgeDTO[]>([]);
    const [lastNumber, setLastNumber] = useState(1);
    const [currentEdgeType, setCurrentEdgeType] = useState<UMLEdgeType>('association');
    const [sheetMeta, setSheetMeta] = useState<UMLSheetMetaDTO>({
        id: Date.now(),
        name: 'Новый лист',
        snapToGrid: false,
        moveLock: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
    });

    const isValidConnection = useCallback((connection: UMLClassEdgeDTO | Connection): boolean => {
        if (!connection.source || !connection.target) return false;
        if (connection.source === connection.target) return false;
        const existingEdge = edges.find(e => e.source === connection.source && e.target === connection.target);
        return !existingEdge;
    }, [edges]);

    const onConnect = useCallback((params: UMLClassEdgeDTO | Connection) => {
        if (!isValidConnection(params)) return;

        const newEdge: UMLClassEdgeDTO = {
            ...params,
            id: `edge-${Date.now()}`,
            type: currentEdgeType,
            data: { type: currentEdgeType }
        };
        setEdges((eds) => addEdge(newEdge, eds));
    }, [currentEdgeType, isValidConnection]);

    const onNodesChange = useCallback((changes: NodeChange<UMLClassNodeDTO>[]) => {
        setNodes(nds => applyNodeChanges(changes, nds))
    }, []);

    const onEdgesChange = useCallback((changes: EdgeChange<Edge>[]) => {
        setEdges(eds => applyEdgeChanges(changes, eds) as UMLClassEdgeDTO[])
    }, []);

    const onEdgeDelete = useCallback((edgesToDelete: Edge[]) => {
        setEdges(eds => eds.filter(e => !edgesToDelete.find(del => del.id === e.id)));
    }, []);

    const addClass = () => {
        const nodeId = Date.now().toString();
        setNodes(p => [...p, {
            id: nodeId,
            position: { x: 100, y: 100 },
            type: 'UMLClass',
            data: {
                name: `Класс №${lastNumber}`,
                attributes: [],
                methods: [],
                onChange: newData => updateNode(nodeId, newData),
                onDelete: () => deleteNode(nodeId)
            }
        }]);
        setLastNumber(n => n + 1);
    };

    const handleSheetMetaChange = <K extends keyof UMLSheetMetaDTO>(
        key: K,
        value: UMLSheetMetaDTO[K]
    ) => {
        setSheetMeta((prev) => ({
            ...prev,
            [key]: value,
            updatedAt: new Date().toISOString(),
        }));
    };

    const updateNode = (nodeId: string, newData: UMLClassNodeData) => {
        setNodes(nds =>
            nds.map(node => {
                if (node.id !== nodeId) return node;
                return {
                    ...node,
                    data: {
                        ...newData
                    }
                };
            })
        );
    };

    const deleteNode = (nodeId: string) => {
        setNodes(nds => nds.filter(n => n.id !== nodeId));
        setEdges(eds => eds.filter(e => e.source !== nodeId && e.target !== nodeId));
    };

    const handleZoomIn = useCallback(() => {
        zoomIn({ duration: 200 });
    }, [zoomIn]);

    const handleZoomOut = useCallback(() => {
        zoomOut({ duration: 200 });
    }, [zoomOut]);

    const handleFitView = useCallback(() => {
        fitView({
            padding: 0.2,
            duration: 300,
            maxZoom: 1.5
        });
    }, [fitView]);

    const handleExport = useCallback(async () => {
        if (nodes.length === 0) return;

        setNodes(nds => nds.map(n => ({ ...n, selected: false })));
        setEdges(eds => eds.map(e => ({ ...e, selected: false })));

        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

        const bounds = getNodesBounds(nodes);
        const padding = 48;
        const width = bounds.width + padding * 2;
        const height = bounds.height + padding * 2;

        const { x, y, zoom } = getViewportForBounds(bounds, width, height, 0.5, 2, padding);

        const toolbar = document.querySelector('[class*="container"]') as HTMLElement;
        const toolbarPrevDisplay = toolbar?.style.display || '';
        if (toolbar) toolbar.style.display = 'none';

        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

        // Собираем все edges в один SVG через строку
        const edgesContainer = document.querySelector('.react-flow__edges') as HTMLElement;
        const originalSvgs = edgesContainer?.querySelectorAll('svg') || [];

        let mergedSvg: SVGElement | null = null;

        if (originalSvgs.length > 0) {
            // Собираем весь внутренний HTML из всех SVG
            let innerContent = '';
            originalSvgs.forEach(svg => {
                innerContent += svg.innerHTML;

                // Скрываем оригинал
                (svg as HTMLElement).style.display = 'none';
            });

            // Создаём новый SVG и вставляем через innerHTML
            mergedSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            mergedSvg.setAttribute('width', `${width}`);
            mergedSvg.setAttribute('height', `${height}`);
            mergedSvg.setAttribute('viewBox', `0 0 ${width} ${height}`);
            mergedSvg.style.position = 'absolute';
            mergedSvg.style.top = '0';
            mergedSvg.style.left = '0';
            mergedSvg.style.zIndex = '0';
            mergedSvg.style.overflow = 'visible';
            mergedSvg.innerHTML = innerContent;

            edgesContainer.appendChild(mergedSvg);
        }

        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

        const viewport = document.querySelector('.react-flow__viewport') as HTMLElement;
        let dataUrl = '';

        if (viewport) {
            try {
                dataUrl = await toPng(viewport, {
                    backgroundColor: '#ffffff',
                    width,
                    height,
                    style: {
                        width: `${width}px`,
                        height: `${height}px`,
                        transform: `translate(${x}px, ${y}px) scale(${zoom})`,
                    },
                });
            } catch (error) {
                console.error('Ошибка экспорта:', error);
            }
        }

        // Восстанавливаем
        if (mergedSvg && edgesContainer) {
            edgesContainer.removeChild(mergedSvg);
        }
        originalSvgs.forEach(svg => {
            (svg as HTMLElement).style.display = '';
        });

        if (toolbar) toolbar.style.display = toolbarPrevDisplay;

        if (dataUrl) {
            if (window.electron) {
                const savedPath = await window.electron.saveFile(`${sheetMeta.name}.png`, dataUrl);
                if (savedPath) console.log('Сохранено в:', savedPath);
            } else {
                const link = document.createElement('a');
                link.download = `${sheetMeta.name}.png`;
                link.href = dataUrl;
                link.click();
            }
        }

        const testSvg = document.querySelector('.react-flow__edges svg:last-child');
        console.log(testSvg?.outerHTML);
    }, [nodes, sheetMeta.name]);

    return (
        <div style={{ width: '100%', height: '100vh', cursor: 'default' }}>
            <EditorToolbar
                data={sheetMeta}
                onChange={handleSheetMetaChange}
                onClassAdd={addClass}
                onFit={handleFitView}
                onZoomIn={handleZoomIn}
                onZoomOut={handleZoomOut}
                onExport={handleExport}
                currentEdgeType={currentEdgeType}
                onEdgeTypeChange={setCurrentEdgeType}
            />
            <ReactFlow
                nodesDraggable={!sheetMeta.moveLock}
                nodes={nodes}
                edges={edges}
                nodeTypes={nodeTypes}
                edgeTypes={edgeTypes}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                onEdgesDelete={onEdgeDelete}
                isValidConnection={isValidConnection}
                snapToGrid={sheetMeta.snapToGrid}
                snapGrid={[20, 20]}
                fitView
                deleteKeyCode="Delete"
                connectionMode={ConnectionMode.Loose}
            >
                <Background variant={BackgroundVariant.Cross} />
            </ReactFlow>
        </div>
    );
};